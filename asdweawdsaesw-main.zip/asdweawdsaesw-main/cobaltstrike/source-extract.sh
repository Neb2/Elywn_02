# (C) Fortra, LLC and its group of companies. All trademarks and registered trademarks are the property of their respective owners.
# ------------------------------------------------------------------
# BASH source routines for consolidated JAR manipulation support
# ------------------------------------------------------------------

CONSOLIDATED_JAR="./cobaltstrike.jar"

# ------------------------------------------------------------------
# Extract a file from the consolidated JAR file.
# ------------------------------------------------------------------
# $1 = File name to extract
# ------------------------------------------------------------------
function extractFileFromJar () {

  print_section_header "Extracting $1 from ${CONSOLIDATED_JAR}"

  FILENAME=$1

  if [ ! -e ${CONSOLIDATED_JAR} ]; then
    print_error "Source JAR file does not exist: ${CONSOLIDATED_JAR}"
    exit 1
  fi

  if [ -f "${FILENAME}" ]; then
    print_error "${FILENAME} file exists already."
    exit 1
  fi

  # echo
  # print_info "Extracting ${FILENAME} from JAR ${CONSOLIDATED_JAR}"

  java -cp "${CONSOLIDATED_JAR}" cszip.CSExtract "${CONSOLIDATED_JAR}" "${FILENAME}"
  if [ $? -ne 0 ]; then
    print_error "Error extracting ${FILENAME} from ${CONSOLIDATED_JAR}"
    exit 1
  fi

  # NOTE: This extracts everything that starts with the specified file name,
  #       so it can also get the corresponding MD5 files as well.
  # jar -xvf "${CONSOLIDATED_JAR}" "${FILENAME}"
  # if [ $? -ne 0 ]; then
  #  print_error "Error extracting file (${FILENAME}) from consolidated JAR: ${CONSOLIDATED_JAR}"
  #  exit 1
  # fi

  # The '...next.md5' file can be deleted.  It is extracted accidentally...
  # if [ -e "./${FILENAME}.next.md5" ]; then
  #  rm -rf "./${FILENAME}.next.md5"
  # fi

}

# -----------------------------------------------------------
# Extract an EXECUTABLE file from a Consolidated JAR.
#   1) Use common extract routine.
#   2) Set the extracted file as 'executable'.
# -----------------------------------------------------------
# $1 = Name of file to extract
# -----------------------------------------------------------
function extractExecFileFromJar () {

  extractFileFromJar "${1}"

  # echo
  # print_info "Setting ${FILENAME} executable"

  chmod +x ./${FILENAME}
  if [ $? -ne 0 ]; then
    print_error "Error setting file executable: ${FILENAME}"
    exit 1
  fi
}

# -----------------------------------------------------------
# Verify that the calculated checksum of a file matches an
# expected checksum value.
#   1) The expected checksum value should be found in a 
#      file named "[filename].md5"
#   2) The MD5 file should be available with the file being
#      checked (already extracted from consolidated JAR).
# -----------------------------------------------------------
# $1 = Filename to verify
# $1 = MD5 Filename
# -----------------------------------------------------------
function verifyChecksum () {

  print_section_header "Verifying MD5 Message Digest for ${1}"

  FileName="${1}"
  MD5FileName="${2}"

  # Remove current MD5 checksum file?
  # if [ -e "./${MD5FileName}" ]; then
  #  rm -f "./${MD5FileName}"
  #  if [ $? -ne 0 ]; then
  #    print_error "Error cleaning up md5 file: ${MD5FileName}"
  #    exit 1
  #  fi
  # fi

  # Extract MD5 checksum file?
  if [ ! -e "./${MD5FileName}" ]; then

    # jar -xvf "${CONSOLIDATED_JAR}" "${MD5FileName}"
    java -cp "${CONSOLIDATED_JAR}" cszip.CSExtract "${CONSOLIDATED_JAR}" "${MD5FileName}"

    if [ $? -ne 0 ]; then
      print_error "Error extracting MD5 file (${MD5FileName}) from consolidated JAR: ${CONSOLIDATED_JAR}"
      exit 1
    fi
  fi

  if md5sum -c ${MD5FileName}; then
    # print_info "The MD5SUM validation passed for ${FileName}"
    : # noop
  else
    print_error "The MD5SUM of file ${FileName} does not match the sum from ${MD5FileName}"
    exit 1
  fi
}

# -----------------------------------------------------------
# Check if the consolidated jar has a different (NEWER) version of a file...
#   1) Compare the MD5 of the current file with a MD5 from the 
#      "...next.md5" file in the consolidated JAR.
#   1) There should be a MD5 file named "[filename].next.md5" for this.
# -----------------------------------------------------------
# $1 = Filename to check
# $2 = MD5 Filename to check
# $3 = Next MD5 Filename to check
# -----------------------------------------------------------
function checkForUpdate () {

  # If the file we are checking does not exist, get out.
  if [ ! -e "./${1}" ]; then
    return
  fi

  print_section_header "Checking $1 for local update"

  FileName="${1}"
  MD5FileName="${2}"
  NextMD5FileName="${3}"

  # Delete the current version of the 'next' MD5 file...
  if [ -e "${NextMD5FileName}" ]; then
    rm -f "${NextMD5FileName}"
    if [ $? -ne 0 ]; then
      print_error "Error deleting next MD5 file: ${NextMD5FileName}"
      exit 1
    fi
  fi

  # Re-Extract the 'next' MD5 file to see if it changed.
  # print_info "Extracting MD5 file ${NextMD5FileName} from ${CONSOLIDATED_JAR}"

  # jar -xvf "${CONSOLIDATED_JAR}" "${NextMD5FileName}"
  java -cp "${CONSOLIDATED_JAR}" cszip.CSExtract "${CONSOLIDATED_JAR}" "${NextMD5FileName}"

  if [ $? -ne 0 ]; then
    print_error "Error extracting MD5 file (${NextMD5FileName}) from consolidated JAR: ${CONSOLIDATED_JAR}"
    exit 1
  fi

  # CAUTION: stdout/stderr redirected to null
  if md5sum -c ${NextMD5FileName} > /dev/null 2>&1; then
    # print_info "The ${FileName} file is current."
    rm -rf "./${NextMD5FileName}"
    return
  else
    # print_info "The ${FileName} file is NOT current. The MD5SUM does not match the 'next' MD5 in consolidated JAR."
    print_info "Updated file detected. Removing current version of: ./${FileName}"
    rm -rf "./${FileName}"
    rm -rf "./${MD5FileName}"
    rm -rf "./${NextMD5FileName}"
    # -------------------
    # We are depending on a subsequent process to restore the new version...
    # -------------------
  fi
}
