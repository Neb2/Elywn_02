# (C) Fortra, LLC and its group of companies. All trademarks and registered trademarks are the property of their respective owners.
# ------------------------------------------------------------------
# BASH source routines for TeamServerImage support
# ------------------------------------------------------------------

export TSImageFile="TeamServerImage"
export TSImageFileMD5="TeamServerImage.md5"
export TSImageFileNextMD5="TeamServerImage.next.md5"

# ------------------------------------------------------------------
# General TeamServerImage Preparation
#    - Check For Update
#    - Extract from consolidated JAR as needed
#    - Verify Checksum
# ------------------------------------------------------------------
function prepareTeamServerImage () {

  # Is there a new version downloaded?
  # If yes, Delete the current version...
  if [ -e "./${TSImageFile}" ]; then
    checkForUpdate "${TSImageFile}" "${TSImageFileMD5}" "${TSImageFileNextMD5}"
  fi
  
  # Do we need to extract the Teamserver Image file from the consolidated JAR?
  if [ ! -e "./${TSImageFile}" ]; then
    extractExecFileFromJar "${TSImageFile}"
  fi
  
  # Check for file corruption...
  verifyChecksum "${TSImageFile}" "${TSImageFileMD5}"

}
