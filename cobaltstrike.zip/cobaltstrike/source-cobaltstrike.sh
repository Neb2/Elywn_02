# (C) Fortra, LLC and its group of companies. All trademarks and registered trademarks are the property of their respective owners.
# ------------------------------------------------------------------
# BASH source runtines for cobaltstrike JAR support
# ------------------------------------------------------------------

export CSJAR="cobaltstrike-client.jar"
export CSJAR_MD5="cobaltstrike-client.md5"
export CSJAR_NEXT_MD5="cobaltstrike-client.next.md5"

# ------------------------------------------------------------------
# General Setup
# ------------------------------------------------------------------
function setupCobaltStrike () {
  # Nothing to do here? ('true' is a 'noop' placeholder)
  true
}

# ------------------------------------------------------------------
# Print Java Information (mostly for debugging)
# ------------------------------------------------------------------
function logJava () {
  # Nothing to do here? ('true' is a 'noop' placeholder)
  true  

  # print_section_header "Logging JAVA Info"
  # print_info "JAVA_HOME: $JAVA_HOME"
  # print_info "PATH: $PATH"
  # echo
  # print_info "WHERE IS JAVA?"
  # whereis java
  # echo
  # print_info "JAVA VERSION?"
  # java -version
}

# ------------------------------------------------------------------
# Configure and Check Java (mostly for development environments)
# ------------------------------------------------------------------
function setupJava () {
  # Nothing to do here? ('true' is a 'noop' placeholder)
  true  

  # print_section_header "Setting up java"
  # -------------------------------------
  # Oracle JVM? 1.8 or later required.
  # -------------------------------------
  # export JAVA_HOME=/usr/share/jdk1.8.0_301/jre/bin/
  # export PATH=$JAVA_HOME:$PATH
  
  # -------------------------------------
  # OpenJDK JVM? 1.11 or later required.
  # -------------------------------------
  # export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
  # export PATH=$JAVA_HOME/bin:$PATH
  
  # Is java installed?
  # print_info "Is java installed (Oracle 1.8+ OR OpenJdK 1.11+)?"
  # if ! command -v java; then
  #   echo
  #   print_error "Java is not available.  Please install java."
  #   exit 1
  # else
  #   echo
  #   print_good "Java is available."
  # fi
}

# ------------------------------------------------------------------
# General cobaltstrike Client JAR Preparation
#    - Check For Update
#    - Extract from consolidated JAR as needed
#    - Verify Checksum
# ------------------------------------------------------------------
function prepareCobaltStrikeJAR () {

  # Is there a new version downloaded?
  # If yes, Delete the current version...
  if [ -e "./${CSJAR}" ]; then
    checkForUpdate "${CSJAR}" "${CSJAR_MD5}" "${CSJAR_NEXT_MD5}"
  fi

  # Do we need to extract the JAR file from the consolidated JAR?
  if [ ! -e ${CSJAR} ]; then
    extractFileFromJar "${CSJAR}"
  fi

  # Check for file corruption...
  verifyChecksum "${CSJAR}" "${CSJAR_MD5}"
}
